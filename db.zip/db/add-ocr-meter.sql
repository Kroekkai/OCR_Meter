-- add-ocr-meter.sql — เพิ่มตาราง ocr_meter เข้า database ที่มีอยู่แล้ว
-- (cfo_iot) โดยไม่แตะตารางเดิมเลย ปลอดภัยรันซ้ำได้ (IF NOT EXISTS)
--
-- รันด้วย: psql -h <host> -U <user> -d cfo_iot -f db/add-ocr-meter.sql
-- หรือ copy เนื้อหาไปรันใน pgweb -> Query tab ก็ได้
--
-- (เนื้อหาเดียวกับที่เพิ่มเข้า db/init.sql แล้ว — ไฟล์นี้แยกไว้ให้รัน
-- เฉพาะส่วนนี้กับ DB ที่มีอยู่แล้วโดยไม่ต้องรันทั้ง init.sql ใหม่)

CREATE TABLE IF NOT EXISTS ocr_meter (
    id                  BIGSERIAL   PRIMARY KEY,
    meter_id            TEXT        NOT NULL,
    reading_date        DATE        NOT NULL,
    reading_time        TIME        NOT NULL,
    ocr_reading         NUMERIC,
    error_type          TEXT        CHECK (error_type IS NULL OR error_type IN ('no_digits_found', 'image_unreadable', 'reading_decreased')),
    error_detail        TEXT,
    ocr_image_filename  TEXT
);

CREATE INDEX IF NOT EXISTS idx_ocr_meter_meter_id ON ocr_meter (meter_id, reading_date DESC, reading_time DESC);

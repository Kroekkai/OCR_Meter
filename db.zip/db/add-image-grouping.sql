-- add-image-grouping.sql — เพิ่มความสามารถ "รวมกลุ่มภาพ burst" เข้า
-- images_electric/water/gas ที่มีอยู่แล้ว โดยไม่ทำข้อมูลเดิมหาย
--
-- รันด้วย: psql -h <host> -U <user> -d <db> -f db/add-image-grouping.sql
-- หรือ copy เนื้อหาไปรันใน pgweb -> Query tab ก็ได้
--
-- ปลอดภัยรันกับ DB ที่มีข้อมูลอยู่แล้ว: แถวเก่าทุกแถวจะถูก backfill ให้
-- เป็น "กลุ่มของตัวเอง" (group_id = id ของตัวเอง) เท่ากับปฏิบัติเหมือน
-- เคยเป็นกลุ่มละ 1 ภาพมาตลอด — ไม่กระทบ ocr_jobs/ocr_meter ที่มีอยู่แล้ว

DO $$
DECLARE
    tbl TEXT;
BEGIN
    FOREACH tbl IN ARRAY ARRAY['images_electric', 'images_water', 'images_gas']
    LOOP
        EXECUTE format('ALTER TABLE %I ADD COLUMN IF NOT EXISTS group_id BIGINT', tbl);
        EXECUTE format('ALTER TABLE %I ADD COLUMN IF NOT EXISTS received_at TIMESTAMPTZ', tbl);

        -- backfill แถวเก่า: ถือว่าแต่ละแถวเป็นกลุ่มของตัวเอง
        EXECUTE format('UPDATE %I SET group_id = id WHERE group_id IS NULL', tbl);
        EXECUTE format(
            'UPDATE %I SET received_at = COALESCE(device_timestamp, now()) WHERE received_at IS NULL',
            tbl
        );

        EXECUTE format('ALTER TABLE %I ALTER COLUMN group_id SET NOT NULL', tbl);
        EXECUTE format('ALTER TABLE %I ALTER COLUMN received_at SET NOT NULL', tbl);
        EXECUTE format('ALTER TABLE %I ALTER COLUMN received_at SET DEFAULT now()', tbl);
    END LOOP;
END $$;

CREATE INDEX IF NOT EXISTS idx_images_electric_group_lookup ON images_electric (meter_id, received_at) WHERE group_id = id;
CREATE INDEX IF NOT EXISTS idx_images_water_group_lookup    ON images_water    (meter_id, received_at) WHERE group_id = id;
CREATE INDEX IF NOT EXISTS idx_images_gas_group_lookup      ON images_gas      (meter_id, received_at) WHERE group_id = id;
